import java.util.Scanner;

public class TimeClock {
    public static void main(String[] args) {
        Admin admin = new Admin();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add Employee");
            System.out.println("2. Remove Employee");
            System.out.println("3. Employee Clock In");
            System.out.println("4. Employee Clock Out");
            System.out.println("5. Generate Payroll");
            System.out.println("6. Exit");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();

            //The switch allows different choices for whatever the user inputs.
            switch (choice) {
                case 1:
                    System.out.print("Enter Employee ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Employee Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Hourly Rate: ");
                    double hourlyRate = scanner.nextDouble();
                    admin.addEmployee(id, name, hourlyRate);
                    break;

                case 2:
                    System.out.print("Enter Employee ID to Remove: ");
                    id = scanner.nextInt();
                    admin.removeEmployee(id);
                    break;

                case 3:
                    System.out.print("Enter Employee ID to Clock In: ");
                    id = scanner.nextInt();
                    Employee emp = admin.getEmployee(id);
                    if (emp != null) {
                        emp.clockIn();
                    } else {
                        System.out.println("Employee not found!");
                    }
                    break;

                case 4:
                    System.out.print("Enter Employee ID to Clock Out: ");
                    id = scanner.nextInt();
                    emp = admin.getEmployee(id);
                    if (emp != null) {
                        emp.clockOut();
                    } else {
                        System.out.println("Employee not found!");
                    }
                    break;

                case 5:
                    admin.generatePayroll();
                    break;

                case 6:
                    System.out.println("Exiting program. Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}