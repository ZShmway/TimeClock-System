import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.Duration;

public class Employee {
    private int id;
    private String name;
    private double hourlyRate;
    private LocalDateTime clockInTime;
    private double totalHoursWorked;

    public Employee(int id, String name, double hourlyRate) {
        this.id = id;
        this.name = name;
        this.hourlyRate = hourlyRate;
        this.totalHoursWorked = 0;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public double getHourlyRate() {
        return hourlyRate;
    }
    public double getTotalHoursWorked() {
        return totalHoursWorked;
    }
    public void clockIn() {
        if (clockInTime != null) {
            System.out.println("Already clocked in!");
            return;
        }
        clockInTime = LocalDateTime.now();
        System.out.println("Clocked in at: " + clockInTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
    }

    public void clockOut() {
        if (clockInTime == null) {
            System.out.println("Not clocked in!");
            return;
        }
        LocalDateTime clockOutTime = LocalDateTime.now();
        System.out.println("Clocked out at: " + clockOutTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));

        double hoursWorked = Duration.between(clockInTime, clockOutTime).toMinutes() / 60.0;
        totalHoursWorked += hoursWorked;
        clockInTime = null;

        System.out.println("Hours worked this session: " + hoursWorked);
    }

    public double calculatePay() {
        return totalHoursWorked * hourlyRate;
    }
}