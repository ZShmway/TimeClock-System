import java.util.HashMap;

public class Admin {
    private HashMap<Integer, Employee> employees = new HashMap<>();

    public void addEmployee(int id, String name, double hourlyRate) {
        if (employees.containsKey(id)) {
            System.out.println("Employee ID already exists!");
            return;
        }
        employees.put(id, new Employee(id, name, hourlyRate));
        System.out.println("Employee added: " + name);
    }

    //If a user removes an employee.
    //If a user tries entering an ID of an employee that was removed. This will prompt the program to print out that an employee ID was not found.
    public void removeEmployee(int id) {
        if (employees.remove(id) != null) {
            System.out.println("Employee removed successfully!");
        } else {
            System.out.println("Employee ID not found!");
        }
    }

    //
    public void generatePayroll() {
        System.out.println("Payroll Summary:");
        for (Employee employee : employees.values()) {
            System.out.printf("ID: %d, Name: %s, Total Hours: %.2f, Total Pay: $%.2f\n",
                    employee.getId(), employee.getName(), employee.getTotalHoursWorked(), employee.calculatePay());
        }
    }

    public Employee getEmployee(int id) {
        return employees.get(id);
    }
}